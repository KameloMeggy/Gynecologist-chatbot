$(document).ready(function () {

  // message structure for the chatbot
  const chatbot_msg_bubble = $('div.chatbot-msg-bubble');

  // message structure for the user
  const user_msg_bubble = $('div.user-msg-bubble');
  
  function popUserMessage(text_msg) {
    msg = user_msg_bubble.clone();

    $('div.talktext p', msg).text(text_msg);
    
    setTimeout(function() {
      var messagePanel = $('div.message-panel');
      messagePanel.append(msg.hide().fadeIn(1000));

      var current_height = messagePanel[0].scrollHeight;
      messagePanel.scrollTop(current_height);
    }, 500);
  }

  function chatbotResponse(text_msg) {
    var msg = chatbot_msg_bubble.clone();

    $('div.talktext p', msg).text(text_msg);

    setTimeout(function() {
      var messagePanel = $('div.message-panel');
      messagePanel.append(msg.hide().fadeIn(1000));

      var current_height = messagePanel[0].scrollHeight;
      messagePanel.scrollTop(current_height);
    }, 1000);
  }

  function sendMessage() {
    var user_msg = $('input[name="write_message"]').val();
    popUserMessage(user_msg);

    // get response from chatbot
    var chatbot_msg = getResponse(user_msg.toLowerCase());
    console.log('Chatbot Response: '+ chatbot_msg);
    chatbotResponse(chatbot_msg);
    

    // clear text in 'write message' text field
    $('input[name="write_message"]').val('');

    // prevents the page from refreshing
    return false;
  }

  // initiate first message from chatbot
  chatbotResponse('Good day, my name is Megygyn!');

  $('button.send').click(sendMessage);

  $('input[name="write_message"]').on('keypress', function (e) {
    if(e.which === 13){

      //Disable textbox to prevent multiple submit
      $(this).attr("disabled", "disabled");

      //Do Stuff, submit, etc..
      sendMessage();

      //Enable the textbox again if needed.
      $(this).removeAttr("disabled");
    }
  });

  populateBookings();
});