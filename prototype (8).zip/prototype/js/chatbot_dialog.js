const responses = {
  age_question :"How old are you?",
  age_neg:"Sorry you don’t meet the requirement to chat with Megygyn good bye.",
  appointment_or_question:"Would you like to book an appointment with Dr Shakumu or ask a question?",
  // appointment:"Please contact Dr Shakumu to book your appointment at 0816416471.",
  appointment:"When would you like to book for an appointment? Acceptable format: DD-MM-YYYY HH:MM",
  question:"What type of question would you like to ask?",
  family_planning_question:"Intrauterine or IUD, also called the coil up can be used from 5 to 10 years) its female sterilization it may have side effect at the early stage depend how the body react to it but according to a specialist gynaecology DR Shakumu it’s the best family planning one can use.",
  family_planning_effects:"Some family planning may cause irregular bleeding, no period, headaches, nausea/dizziness and weight gain/loss",
  period_pain_question:"What cause period pain?",
  period_pain_answer:"Endometriosis, Uterine Fibroids or Cervical Stenosis are the causes of period pain",
  heavy_period_pain_question:"What cause heavy period pain?",
  heavy_period_pain_answer:"Can cause by condition affecting your womb, ovaries and hormones such as polycystic ovary syndrome, fibroids, pelvic inflammatory disease. However, stress and depression can cause also heavy period pain",
  vaginal_discharge_question:"What is vaginal discharge and if it’s normal?",
  vaginal_discharge_answer:"A normal discharge should be clear or white and it shouldn’t smell bad it may have an odor but shouldn’t be strong or unpleasant. Contact a healthcare provider if you notice any change on the way your vaginal discharge smell, look, texture or if it cause irritation, itching or pain.",
  default_response:"I have no idea about this question please contact Dr Shakumu at 081641647 a gynaecologist at Katutura hospital she will help you out.",
  good_bye_response:"Thanks for contacting Megygyn don’t hesitate to come back in case you need help. And if you want to see a physical gynaecologist call or text Dr Shakumu at 081641647 she will help you out on how to get one. Have a blessed day",
};

var age_qualification = false;
var appointment_or_question = false;
var appointment = false;
var question = false;

const months = ["January", "February", "March", "April", "May", "June"
, "July", "August", "September", "October", "November", "December"];

today = new Date();
var booking = {
  date: today,
  start_time: String(today.getHours()).padStart(2, '0') + ':' + String(today.getMinutes()).padStart(2, '0'),
  end_time: String(today.getHours() + 2).padStart(2, '0') + ':' + String(today.getMinutes()).padStart(2, '0')
};

const bookings = [];
bookings[0] = booking;

function createBooking() {
  // cross reference all current bookings with the propossed booking

}

function populateBookings() {
  var str = '';
  for (let index = 0; index < bookings.length; index++) {
    const element = bookings[index];
    str += '<p>'+ (index + 1) +'. Appointment with Dr. Shakumu - '+ 
    element.date.getDate() + ' ' + months[element.date.getMonth()].substring(0, 3) + ' ' + element.date.getFullYear() 
    +' @ '+ element.start_time +'</p>';
  }

  $('div.appointment-list').html(str);
}

function reverseDate(date_str) {
  var date_elements = date_str.split('-');

  return date_elements[2] + '-' + date_elements[1] + '-' + date_elements[0];
}

function getResponse(user_msg) {
  if ((user_msg.includes('hello') || user_msg.includes('hey') || user_msg.includes('hi')) && !appointment_or_question) {
    return responses.age_question;
  } else if (!isNaN(user_msg)) {
    if (user_msg < 15) {
      age_qualification = false;
      return responses.age_neg;
    } else {
      age_qualification = true;
    }
  }

  if (age_qualification) {
    if (!appointment_or_question) {
      appointment_or_question = true;
      return responses.appointment_or_question;
    } else if(!question && user_msg.includes('question')) {
      question = true;
      appointment = false;
      return responses.question;
    } else if (!appointment && user_msg.includes('appointment')) {
      appointment = true;
      question = false;
      return responses.appointment;
    } else if (appointment) {
      // Get appointment date and time from the user.
      var input_datetime = user_msg.trim().split(' ');
      var date_str = input_datetime[0].replace('_', '-');
      date_str = input_datetime[0].replace('/', '-');
      date_str = input_datetime[0].replace('\\', '-');
      date_str = reverseDate(date_str);
      

      var time_str = input_datetime[1];

      bookings[bookings.length] = {
        date : new Date(date_str +' '+ time_str),
        start_time : String(booking.date.getHours()).padStart(2, '0') + ':' + String(booking.date.getMinutes()).padStart(2, '0'),
        end_time : String(booking.date.getHours() + 2).padStart(2, '0') + ':' + String(booking.date.getMinutes()).padStart(2, '0')
      }; // record booking

      populateBookings();

      appointment = false;
      return 'Booking made successfully! ' + responses.appointment_or_question;

    } else if (question) {
      var str = '';
      if ((user_msg.includes('family') || user_msg.includes('planning')) && user_msg.includes('effect')) {
        str += responses.family_planning_effects;
      } else if (user_msg.includes('family') || user_msg.includes('planning')) {
        str += responses.family_planning_question;
      } else if ((user_msg.includes('period') || user_msg.includes('pain')) && user_msg.includes('heavy')) {
        str += responses.heavy_period_pain_answer;
      } else if (user_msg.includes('period') || user_msg.includes('pain')) {
        str += responses.period_pain_answer;
      } else if (user_msg.includes('vaginal') || user_msg.includes('discharge')) {
        str += responses.vaginal_discharge_answer;
      } else if (user_msg.includes('no') || user_msg.includes('all') || user_msg.includes('that\'s all') || user_msg.includes('no question') || user_msg.includes('no further question')) {
        question = false;
        appointment = false;
        appointment_or_question = false;
        return responses.good_bye_response;
      } else {
        str += responses.default_response;
      }
      return str += '. What other question would you like to ask?';
    }
  }

  return responses.default_response;
}